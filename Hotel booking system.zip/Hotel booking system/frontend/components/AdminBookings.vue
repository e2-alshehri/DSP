<template>
  <div>
    <h2>All Bookings</h2>
    <p>Future admin view for all bookings will be shown here</p>
  </div>
</template>

<script>
export default {}
</script>
